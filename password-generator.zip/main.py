import random
import string

def generate_password(length, complexity):
    if complexity == "easy":
        characters = string.ascii_letters
    elif complexity == "moderate":
        characters = string.ascii_letters + string.digits
    elif complexity == "difficult":
        characters = string.ascii_letters + string.digits + string.punctuation
    else:
        raise ValueError("Invalid complexity level")

    #password contains characters according to the complexity
    if complexity == "moderate":
        password = [
            random.choice(string.ascii_lowercase),
            random.choice(string.ascii_uppercase),
            random.choice(string.digits)
        ]
        length -= 3
    elif complexity == "difficult":
        password = [
            random.choice(string.ascii_lowercase),
            random.choice(string.ascii_uppercase),
            random.choice(string.digits),
            random.choice(string.punctuation)
        ]
        length -= 4
    else:
        password = []

    #Fill the rest of the password length with random characters
    password += random.choices(characters, k=length)
    
    #Shuffle the list to ensure randomness
    random.shuffle(password)
    
    #Converts the list to a string
    password = ''.join(password)
    
    return password

def main():
    print("Password Generator")
    
    #user input for the length of the password
    length = int(input("Enter the desired length for the password: "))
    
    #user input for the complexity of the password
    print("Choose the complexity level:")
    print("1. Easy (lowercase + uppercase letters)")
    print("2. Moderate (letters and digits)")
    print("3. Difficult (letters, digits, and special characters)")
    complexity_choice = input("Enter the number corresponding to the complexity: ")
    
    if complexity_choice == '1':
        complexity = "easy"
    elif complexity_choice == '2':
        complexity = "moderate"
    elif complexity_choice == '3':
        complexity = "difficult"
    else:
        print("Invalid choice")
        return
    
    # Check if the length is valid for the chosen complexity
    min_length = 7 if complexity == "difficult" else (5 if complexity == "moderate" else 3)
    if length < min_length:
        print(f"Password length should be at least {min_length} characters for {complexity} complexity.")
    else:
        # Generate the password
        password = generate_password(length, complexity)
        # display the password
        print(f"Generated Password: {password}")

# Call the main function
if __name__ == "__main__":
    main()

