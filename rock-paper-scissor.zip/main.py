import random

def get_user_choice():
    choices = {1: 'rock', 2: 'paper', 3: 'scissors'}
    print("Choose your option:")
    print("1. Rock")
    print("2. Paper")
    print("3. Scissors")
    
    try:
        user_input = int(input("Enter the number corresponding to your choice: "))
        if user_input in choices:
            return choices[user_input]
        else:
            print("Invalid choice. Please choose a valid option.")
            return get_user_choice()
    except ValueError:
        print("Invalid input. Please enter a number.")
        return get_user_choice()

def get_computer_choice():
    return random.choice(['rock', 'paper', 'scissors'])

def determine_winner(user_choice, computer_choice):
    if user_choice == computer_choice:
        return "tie"
    elif (user_choice == "rock" and computer_choice == "scissors") or \
         (user_choice == "scissors" and computer_choice == "paper") or \
         (user_choice == "paper" and computer_choice == "rock"):
        return "user"
    else:
        return "computer"

def display_result(user_choice, computer_choice, winner):
    print(f"Your choice: {user_choice}")
    print(f"Computer's choice: {computer_choice}")
    if winner == "tie":
        print("It's a tie!")
    elif winner == "user":
        print("You win!")
    else:
        print("Computer wins!")

def play_again():
    while True:
        choice = input("Do you want to play another round? (yes/no): ").lower()
        if choice == 'yes':
            return True
        elif choice == 'no':
            return False
        else:
            print("Invalid command. Please enter 'yes' or 'no'.")
def main():
    user_score = 0
    computer_score = 0

    print("Welcome to Rock, Paper, Scissors Game!")

    while True:
        user_choice = get_user_choice()
        computer_choice = get_computer_choice()
        winner = determine_winner(user_choice, computer_choice)
        
        display_result(user_choice, computer_choice, winner)
        
        if winner == "user":
            user_score += 1
        elif winner == "computer":
            computer_score += 1
        
        print(f"Score -> You: {user_score}, Computer: {computer_score}")

        if not play_again():
            break

    print("Thanks for playing!")

# Call the main function
if __name__ == "__main__":
    main()

