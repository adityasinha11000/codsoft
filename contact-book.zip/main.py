import json
import re

contacts = []

def save_contacts():
    with open('contacts.json', 'w') as file:
        json.dump(contacts, file)

def load_contacts():
    global contacts
    try:
        with open('contacts.json', 'r') as file:
            contacts = json.load(file)
    except FileNotFoundError:
        contacts = []

def validate_phone(phone):
    return phone.isdigit() and len(phone) == 10

def validate_email(email):
    return "@" in email

def add_contact():
    name = input("Enter name: ")
    phone = input("Enter phone number (10 digits): ")
    while not validate_phone(phone):
        print("Invalid phone number. Please enter a 10-digit phone number.")
        phone = input("Enter phone number (10 digits): ")
        
    email = input("Enter email: ")
    while not validate_email(email):
        print("Invalid email. Please include an '@' in the email address.")
        email = input("Enter email: ")
        
    address = input("Enter address: ")
    contacts.append({
        'name': name,
        'phone': phone,
        'email': email,
        'address': address
    })
    save_contacts()
    print("Contact added successfully.")

def view_contacts():
    if not contacts:
        print("No contacts available.")
    else:
        print("Contact List:")
        for index, contact in enumerate(contacts, start=1):
            print(f"{index}. {contact['name']} - {contact['phone']}")

def search_contacts():
    search = input("Enter name or phone number to search: ").lower()
    found_contacts = [contact for contact in contacts if search in contact['name'].lower() or search in contact['phone']]
    if not found_contacts:
        print("No contacts found.")
    else:
        for contact in found_contacts:
            print(f"Name: {contact['name']}, Phone: {contact['phone']}, Email: {contact['email']}, Address: {contact['address']}")

def update_contact():
    search = input("Enter name or phone number of the contact to update: ").lower()
    for contact in contacts:
        if search in contact['name'].lower() or search in contact['phone']:
            print("Contact found. Enter new details (leave blank to keep current value):")
            contact['name'] = input(f"Name ({contact['name']}): ") or contact['name']
            
            new_phone = input(f"Phone ({contact['phone']}): ")
            while new_phone and not validate_phone(new_phone):
                print("Invalid phone number. Please enter a 10-digit phone number.")
                new_phone = input(f"Phone ({contact['phone']}): ")
            contact['phone'] = new_phone or contact['phone']
            
            new_email = input(f"Email ({contact['email']}): ")
            while new_email and not validate_email(new_email):
                print("Invalid email. Please include an '@' in the email address.")
                new_email = input(f"Email ({contact['email']}): ")
            contact['email'] = new_email or contact['email']
            
            contact['address'] = input(f"Address ({contact['address']}): ") or contact['address']
            save_contacts()
            print("Contact updated successfully.")
            return
    print("Contact not found.")

def delete_contact():
    search = input("Enter name or phone number of the contact to delete: ").lower()
    for contact in contacts:
        if search in contact['name'].lower() or search in contact['phone']:
            contacts.remove(contact)
            save_contacts()
            print("Contact deleted successfully.")
            return
    print("Contact not found.")

def main():
    load_contacts()
    while True:
        print("\nContact Management System")
        print("1. Add Contact")
        print("2. View Contact List")
        print("3. Search Contact")
        print("4. Update Contact")
        print("5. Delete Contact")
        print("6. Exit")
        choice = input("Enter your choice: ")
        
        if choice == '1':
            add_contact()
        elif choice == '2':
            view_contacts()
        elif choice == '3':
            search_contacts()
        elif choice == '4':
            update_contact()
        elif choice == '5':
            delete_contact()
        elif choice == '6':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please enter a number between 1 and 6.")

if __name__ == "__main__":
    main()

