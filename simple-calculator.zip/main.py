def calculator():
    print("Simple Calculator")
    
    # Get user input
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    
    print("Choose the operation:")
    print("1. Addition (+)")
    print("2. Subtraction (-)")
    print("3. Multiplication (*)")
    print("4. Division (/)")
    
    operation = input("Enter the number corresponding to the operation: ")
    
    # Perform the calculation
    if operation == '1':
        result = num1 + num2 #Adds two numbers
        op_symbol = '+'
    elif operation == '2':
        result = num1 - num2  #Subtracts two numbers
        op_symbol = '-'
    elif operation == '3':
        result = num1 * num2   #Multiplies two numbers
        op_symbol = '*'
    elif operation == '4':
        if num2 != 0:
            result = num1 / num2 #Divides two numbers
            op_symbol = '/'
        else:
            result = "undefined (division by zero)"
            op_symbol = '/'
    else:
        result = "invalid operation"
        op_symbol = ''
    
    # Display the result
    if op_symbol:
        print(f"{num1} {op_symbol} {num2} = {result}")
    else:
        print(result)

# Call the calculator function
calculator()
